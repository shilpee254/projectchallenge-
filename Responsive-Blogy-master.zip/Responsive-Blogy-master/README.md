![desktop](https://github.com/Parvej45/Responsive-Blogy/assets/97740459/ce59d4fc-a6ec-4e61-bc6e-628fcf86fd55)
