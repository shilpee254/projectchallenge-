Resume-Builder ✌️✌️✌️

![screencapture-file-C-Users-Hp-Desktop-Resume-Builder-index-html-2023-08-03-14_59_38](https://github.com/Parvej45/Resume-Builder/assets/97740459/45487f6f-6bef-47f4-a79a-c3bc23a9f9f3)

It is a resume generator web app that can build your resume by just simply filling the form with the information You can also print it also in pdf format Tech used:- HTML, CSS, JAVASCRIPT, BOOTSTRAP

Working
1. Fill the form
2. Click to Generate Resume
3. Click to print and Download it
Features
1. Add button is used to add as many Work Experience sections.
2. Add button is used to add as many Education
3. Print button to download the resume
4. Clean Code
5. Profile photo, email, phone no, contact no, GitHub link, linkedin link, education, experience, skill, and objective section included in the template.
